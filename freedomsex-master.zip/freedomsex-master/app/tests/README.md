# Тесты

Материалы для тестирования работы классов, сервисов, модулей приложения. Сейчас для тестирования используется [PHPUnit](https://phpunit.de/) фреймворк.  

[PHPUnit. Автоматические тесты](https://habrahabr.ru/post/87922/)  
[Юнит-тестирование в PHP](https://habrahabr.ru/post/56289/)  
[Google - phpunit](https://www.google.ru/webhp#q=phpunit)  

