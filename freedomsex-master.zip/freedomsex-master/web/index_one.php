<?php  
/**   
 * Временный файл на время приведения движка к новой архитектуре
 * 
 */ 
                 
/*                                  
error_reporting(7);
ini_set('display_errors', true);      */  
                         
                         
  header('Content-Type: text/html; charset=UTF-8');
    
  require_once 'app/bootstap.php'; 
  
